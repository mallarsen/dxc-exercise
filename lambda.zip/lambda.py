import boto3
import json
import os

ssm_client = boto3.client("ssm")
s3_client = boto3.client('s3')

def lambda_handler(event,context):
    param_name = 'UserName1'
    param_value = get_parameter(param_name)
    param_dict = {param_name:param_value}
    write_into_s3(json.dumps(param_dict))
    
def write_into_s3(text):
    s3_client.put_object(Body=text, Bucket=os.environ.get('BucketName'), Key=os.environ.get('FileName'))

def get_parameter(param_name):
    parameter = ssm_client.get_parameter(Name=param_name)
    return parameter["Parameter"]["Value"]